var simcongCommon = (function(){

	return {
		init:function(){
			this.addHandlers();
			this.touchFix();
			this.initAppBanner();
			this.initTopBanner();
		},
		addHandlers:function(){
			var _t = this;
			$("#toggleMemberPopup").click(function(){ _t.toggleMemberPopup(); });
			$(".gnb_toggle_btn,.gnb_close_btn").click(function(){ _t.toggleMenu(); });
			$(".gnb_wrap").click(function(){_t.toggleMenu(false);});
			$(".gnb_inner").click(function(e){ e.stopPropagation(); });
			$("*[data-site-banner=true]").click(function(e){ _t.bannerClickLog($(this)); });

			$(".floating_banner_close").on('click', function(){
				_t.closeFloatingBanner($(this));
			});
		},
		toggleMenu:function(status){
			if(status!==undefined) $('body')[status===true?'addClass':'removeClass']('menu');
			else $('body').toggleClass('menu');
		},
		toggleMemberPopup:function(){
			$(".member_popup").toggleClass('on');
		},
		touchFix:function(){
			$(document).on('click touchend','a,button,input',function(e){
			});
		},
		initTopBanner:function(){
			if($(".top_banner_container").length<1) return;

			var link = "https://instagram.com/simcong.test";
			var banner_id = $(".top_banner_container").attr('data-top-banner-id');

			$(".top_banner_container .btn_top_banner_close").on('click',function(){
				$(".top_banner_container").hide();
				util.setCookie("top_banner_close_"+banner_id, true, 1);
			});



			$(".btn_top_banner_link").on('click', function () {
				gtag('event', '탑 배너 링크 '+banner_id,{
					'event_category':'BANNER'
				});
				window.open(link);
			});

			if(!util.getCookie("top_banner_close_"+banner_id)) { // 헤더배너
				$(".top_banner_container").show();
			}

		},
		initAppBanner:function(){
			if($(".app_banner_container").length<1) return;

			var link = "";

			$(".app_banner_container .btn_app_banner_close").on('click',function(){
				$(".app_banner_container").hide();
				util.setCookie("app_banner_close",true,1);
			});



			$(".btn_app_banner_link").on('click', function () {
					var position = $(this).attr('data-position');
					gtag('event', position+' 앱 배너 링크',{
						'event_category':'APP_BANNER'
					});
				window.open(link);
			});

			if (util.isMobile() === 'android' && util.isApp() === false) {
				link = "https://play.google.com/store/apps/details?id=com.shinefactory.simcong";
				if(!util.getCookie("app_banner_close")) { // 헤더배너
					$(".app_banner_container").show();
				}

				$(".view_app_banner_wrap").show(); // 상세배너

			} else {

			}
		},
		bannerClickLog:function(el){
			var title = el.attr('data-banner-title');
			var position = el.attr('data-banner-position');

			// console.log(title, position);
			gtag('event','사이트 배너 클릭',{
				'event_category':'SITE_BANNER',
				'event_action':position+' banner click',
				'event_label':title
			});
		},
		closeFloatingBanner:function(el){
			var fbody = el.closest('.floating_banner');
			var fid = fbody.attr('data-floating-id');
			$.cookie(fid, '1', { expires: 1 });
			fbody.hide();
		}
	}
})();
simcongCommon.init();
