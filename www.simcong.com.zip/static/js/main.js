var main = (function(){
	var swiper;

	return {
		init:function(){
			this.addHandlers();
			this.mainSlide();
			this.toggleSearchBox();
		},
		addHandlers:function(){
			var _t = this;
			//$(window).resize(function(){ _t.mainSlide(); });
		},
		mainSlide:function(){
			var w = $(window).width();
			if(w>420) {
				$(".main_top").removeClass('swiper-container');
				$(".main_top_list").removeClass('swiper-wrapper');
				$(".main_top_list > li").removeClass('swiper-slide');
				if(typeof swiper === 'object') swiper.destroy();
			}else {
				$(".main_top").addClass('swiper-container');
				$(".main_top_list").addClass('swiper-wrapper');
				$(".main_top_list > li").addClass('swiper-slide');
				swiper = new Swiper('.swiper-container', {
					loop:true,
					autoplay:{
						delay:2000,
						disableOnInteraction:false
					}

				});
			}
		},
		toggleSearchBox:function(){
			$(".search_wrap").click(function(){ $(".search_wrap").addClass('on').find('input').val('').focus(); });
			$(".search_wrap input").blur(function(){
				$(this).closest('.search_wrap').removeClass('on');
			});
		}
	}
})();
main.init();