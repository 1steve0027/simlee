var util = (function(){
	return {
		init:function(){

		},
		pad:function(n, width){
			n = n + '';
			return n.length >= width ? n : new Array(width - n.length + 1).join('0') + n;
		},
		postMessage:function(msg){
			if(!msg) return false;
			window.ReactNativeWebView.postMessage(msg)
		},
		number_format:function (number, decimals, dec_point, thousands_sep) {
			number = (number + '')
				.replace(/[^0-9+\-Ee.]/g, '');
			var n = !isFinite(+number) ? 0 : +number,
				prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
				sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
				dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
				s = '',
				toFixedFix = function(n, prec) {
					var k = Math.pow(10, prec);
					return '' + (Math.round(n * k) / k)
							.toFixed(prec);
				};
			// Fix for IE parseFloat(0.55).toFixed(0) = 0;
			s = (prec ? toFixedFix(n, prec) : '' + Math.round(n))
				.split('.');
			if (s[0].length > 3) {
				s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
			}
			if ((s[1] || '')
					.length < prec) {
				s[1] = s[1] || '';
				s[1] += new Array(prec - s[1].length + 1)
					.join('0');
			}
			return s.join(dec);
		},
		// number_format:function(str) {
		// 	if(typeof str  !== 'string') str = str.toString().replace(/[^0-9]/gi,"");
		// 	return str.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
		// },
		getHanNumber:function(pWon){ // 한글숫자
			if(pWon===0) return 0;
			pWon = Math.floor(pWon/10000)*10000;
			var won  = (pWon+"").replace(/,/g, "");
			var arrWon  = ["원", "만", "억", "조", "경", "해", "자", "양", "구", "간", "정"];
			var changeWon = "";
			var pattern = /(-?[0-9]+)([0-9]{4})/;
			while(pattern.test(won)) {
				won = won.replace(pattern,"$1,$2");
			}
			var arrCnt = won.split(",").length-1;
			for(var ii=0; ii<won.split(",").length; ii++) {
				if(arrWon[arrCnt] === undefined) {
					//alert("값의 수가 너무 큽니다.");
					break;
				}
				var tmpwon=0;
				for(var i=0;i<won.split(",")[ii].length;i++){
					var num1 = won.split(",")[ii].substring(i,i+1);
					tmpwon = tmpwon+Number(num1);
				}
				if(tmpwon > 0){
					changeWon += won.split(",")[ii]+arrWon[arrCnt]; //55억0000만0000원 이런 형태 방지 0000 다 짤라 버린다
				}
				arrCnt--;
			}
			changeWon = changeWon.replace(/([0-9]+)/gi,function(match, number){
				return parseInt(number).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
			});
			return changeWon;
		},
		isApp:function(){
			var isApp = false;
			if(navigator.userAgent.match(/SIMCONG_APP_ANDROID/i)) isApp = "android";
			else if(navigator.userAgent.match(/SIMCONG_APP_IOS/i)) isApp = "ios";
			return isApp;
		},
		isMobile:function() { // 모바일체크
			var check = false;

			var varUA = navigator.userAgent.toLowerCase(); //userAgent 값 얻기

			if ( varUA.indexOf('android') > -1) {
				//안드로이드
				check = "android";
			} else if ( varUA.indexOf("iphone") > -1||varUA.indexOf("ipad") > -1||varUA.indexOf("ipod") > -1 ) {
				//IOS
				check = "ios";
			}

			/*
			if( navigator.userAgent.match(/Android/i)
				|| navigator.userAgent.match(/webOS/i)
				|| navigator.userAgent.match(/iPhone/i)
				|| navigator.userAgent.match(/iPad/i)
				|| navigator.userAgent.match(/iPod/i)
				|| navigator.userAgent.match(/BlackBerry/i)
				|| navigator.userAgent.match(/Windows Phone/i)
			) check=true;
			 */
			return check;
		},
		// hashParameter: function(){ // 해시파라미터 가져오기
		// 	var r={}, t=[], i,
		// 		a=location.hash.substr(1).split('&');
		// 	for(i=0;i<a.length;i+=1){t=a[i].split("=");r[t[0]]=t[1];}
		// 	return r;
		// }(),
		isSafari:function(){
			var ua = navigator.userAgent.toLowerCase();
			if (ua.indexOf('safari') != -1) {
				if (ua.indexOf('chrome') > -1) {
					return false;
				} else {
					return true;
				}
			}
		},
		getHashParameter: function(h){ // hash => object
			var r={}, t=[], i,
				a= h ? h.split('&') : location.hash.substr(1).split('&');

			if(!a[0]) return r;

			for(i=0;i<a.length;i+=1){t=a[i].split("=");r[t[0]]=t[1];}
			return r;
		},
		setHashParameter: function(hash,history,isNew){ // object => hash
			var newHash=[];

			if(!isNew){
				var oldHash=this.getHashParameter();
				hash=$.extend(oldHash,hash);
			}

			for(var h in hash){
				if(hash[h]) newHash.push(h+'='+hash[h]);
			}

			newHash=newHash.join("&");
			if(!history) location.replace("#"+newHash);
			else location.hash=newHash;
		},
		setCookie: function(name,value,days){ // 쿠키 저장하기
			if(name && !value) {
				document.cookie = name+'=; Max-Age=-99999999;';
				return;
			}
			var expires = "";
			if (days) {
				var date = new Date();
				date.setTime(date.getTime() + (days*24*60*60*1000));
				expires = "; expires=" + date.toUTCString();
			}
			document.cookie = name + "=" + (value || "")  + expires + "; path=/";
		},
		getCookie:function(name){ // 쿠키 가져오기
			var nameEQ = name + "=";
			var ca = document.cookie.split(';');
			for(var i=0;i < ca.length;i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1,c.length);
				if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
			}
			return null;
		},
		cutLen:function(str,len){ // 글자 자르기
			String.prototype.byte = function() {
				var str = this;
				var length = 0;
				for(var i = 0; i < str.length; i++)
				{
					if(escape(str.charAt(i)).length >= 4)
						length += 2;
					else if(escape(str.charAt(i)) == "%A7")
						length += 2;
					else
					if(escape(str.charAt(i)) != "%0D")
						length++;
				}
				return length;
			}

			String.prototype.cutByte = function(len) {
				var str = this;
				var count = 0;

				for(var i = 0; i < str.length; i++) {
					if(escape(str.charAt(i)).length >= 4)
						count += 2;
					else
					if(escape(str.charAt(i)) != "%0D")
						count++;


					if(count >  len) {
						if(escape(str.charAt(i)) == "%0A")
							i--;
						break;
					}
				}
				return str.substring(0, i);
			}

			// String.prototype.cutLen = function(len) {
			// 	var str = this;
			// 	return str.substring(0, len);
			// }
			return str.substring(0,len);
		}
	}
})();
